class SignUp {
  final name;
  final email;
  final password;

  SignUp({this.name, this.email, this.password});
}
